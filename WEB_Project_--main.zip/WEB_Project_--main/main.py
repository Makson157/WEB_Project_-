from flask import Flask, render_template, url_for, redirect, request
from data import db_session
from data.product import Product
from data.users import User
from forms.users import RegisterForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route("/")
def index():
    db_sess = db_session.create_session()
    slides = db_sess.query(Product).all()
    return render_template("main.html", title='Главная страница', products=slides)


@app.route("/tovar/<id>")
def product(id):
    db_sess = db_session.create_session()
    product = []
    for i in id.split(','):
        product.append(db_sess.query(Product).filter(Product.id == int(i)).all())
    return render_template("tovar.html", title='Просмотр товара', tovars=product)


@app.route("/korzina")
def korzina():
    db_sess = db_session.create_session()
    product = db_sess.query(User).filter(User.id == 1).all()
    products = []
    for item in product:
        for prod in item.pokupka.split(','):
            products.append(db_sess.query(Product).filter(Product.id == int(prod)).first())
    return render_template("korzina.html", title='Корзина', tovar=products)


@app.route("/lk", methods=['GET', 'POST'])
def lk():
    db_sess = db_session.create_session()
    # user = db_sess.query(User).filter(User.id == id).first()
    form = RegisterForm()
    if form.validate_on_submit():
        return redirect('/success')
    return render_template('lk.html', title='Личный кабинет', form=form)


@app.route("/kateg", methods=['GET', 'POST'])
def kategori():
    if request.method == 'GET':
        db_sess = db_session.create_session()
        products = db_sess.query(Product).all()
        kat = []
        for item in products:
            if item.kategori not in kat:
                kat.append(item.kategori)
        return render_template('kategori.html', title='Категории товаров', kateg=kat)


@app.route("/<kat>", methods=['GET', 'POST'])
def kategori_list(kat):
    db_sess = db_session.create_session()
    products = db_sess.query(Product).filter(Product.kategori == kat).all()
    id = []
    for i in products:
        id.append(str(i.id))
    id = ', '.join(id)
    return redirect(f"http://127.0.0.1:5000/tovar/{id}")


def main():
    db_session.global_init("db/online_shop.db")
    app.run()


if __name__ == '__main__':
    main()
