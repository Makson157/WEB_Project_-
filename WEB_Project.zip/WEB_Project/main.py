from flask import Flask, render_template, url_for
from data import db_session
from data.product import Product

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route("/")
def index():
    db_sess = db_session.create_session()
    slides = db_sess.query(Product).all()
    return render_template("main.html", title='Главная страница', products=slides)


@app.route("/tovar/<int:id>")
def product(id):
    db_sess = db_session.create_session()
    product = db_sess.query(Product).filter(Product.id == id).first()
    return render_template("tovar.html", title='Просмотр товара', tovar=product)


def main():
    db_session.global_init("db/online_shop.db")
    app.run()


if __name__ == '__main__':
    main()
